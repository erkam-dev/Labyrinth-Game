﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kontroltop : MonoBehaviour
{
    public Rigidbody rigidbody;
    public int hiz;
    void Start()
    {
        rigidbody = GetComponent<Rigidbody>();

    }


    void FixedUpdate()
    {
        float yatay = Input.GetAxisRaw("Horizontal");
        float dikey = Input.GetAxisRaw("Vertical");
        Vector3 vector3 = new Vector3(yatay, 0, dikey);
        rigidbody.AddForce(vector3 * hiz);
    }
}
