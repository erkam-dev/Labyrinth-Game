﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class engel_yanma_durumu : MonoBehaviour
{
    public GameObject top;
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "engel")
        {
            Destroy(top);
        }
    }
}
