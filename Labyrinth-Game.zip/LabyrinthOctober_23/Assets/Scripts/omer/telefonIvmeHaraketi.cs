﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class telefonIvmeHaraketi : MonoBehaviour
{
    public bool isflat = true;
    Rigidbody rigid;

    void Start()
    {
        rigid = GetComponent<Rigidbody>();
    }


    void Update()
    {
        Vector3 vector3 = Input.acceleration;
        if (isflat)
        {
            vector3 = Quaternion.Euler(90, 0, 0) * vector3;
        }
        rigid.AddForce(vector3);
        Debug.DrawRay(transform.position + Vector3.up, vector3, Color.red);
    }
}
