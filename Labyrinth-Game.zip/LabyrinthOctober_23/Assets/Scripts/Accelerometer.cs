﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Accelerometer : MonoBehaviour
{
    public bool duzMu = true;
    private Rigidbody rigid;
    public int hiz;
    private void Start()
    {
        rigid = GetComponent<Rigidbody>();

    }

    
    void FixedUpdate()
    {
        Vector3 egim = -Input.acceleration;

        if (duzMu)
            egim = Quaternion.Euler(90, 0, 180) * egim;

        rigid.velocity = egim * hiz;
    }
}
