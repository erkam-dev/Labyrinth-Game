﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChanger : MonoBehaviour
{
    public GameObject Canvas;
    public bool engel = true;
    public GameObject player;
    void OnTriggerEnter(Collider obj)
    {
        /*if (obj.tag == "Finish")
        {
            Debug.Log("finish");
            SceneManager.LoadScene("level-"+(SceneManager.GetActiveScene().buildIndex + 1));
        }*/

        if(obj.tag == "Finish")
        {
            Canvas.SetActive(true);
            engel = false;
        }


        if (obj.tag == "engel")
        {
            if (engel == true)
            {
                SceneManager.LoadScene("level-" + (SceneManager.GetActiveScene().buildIndex));
            }

        }


    }
}
