﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Quit : MonoBehaviour
{

    public GameObject Canvas;
    public void quit()
    {
        Debug.Log("QUIT!");
        Application.Quit();
    }
    
    public void durdur()
    {
        Time.timeScale = 0f;
        Canvas.SetActive(true);
    }
    public void devam()
    {
        Time.timeScale = 1f;
        Canvas.SetActive(false);
    }

    public void restart()
    {
        SceneManager.LoadScene("level-" + (SceneManager.GetActiveScene().buildIndex));
    }
}
